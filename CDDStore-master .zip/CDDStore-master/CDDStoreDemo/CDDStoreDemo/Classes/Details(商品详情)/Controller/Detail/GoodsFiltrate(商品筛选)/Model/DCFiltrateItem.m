//
//  DCFiltrateItem.m
//  CDDStoreDemo
//
//  Created by apple on 2017/8/22.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCFiltrateItem.h"

@implementation DCFiltrateItem


+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"content" : @"DCContentItem"
             };
}



@end
