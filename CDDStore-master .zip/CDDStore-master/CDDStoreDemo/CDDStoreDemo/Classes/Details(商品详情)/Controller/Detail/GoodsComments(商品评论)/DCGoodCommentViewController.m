//
//  DCGoodCommentViewController.m
//  CDDMall
//
//  Created by apple on 2017/6/21.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCGoodCommentViewController.h"

// Controllers

// Models

// Views

// Vendors

// Categories

// Others

@interface DCGoodCommentViewController ()



@end

@implementation DCGoodCommentViewController

#pragma mark - LazyLoad


#pragma mark - LifeCyle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
}

@end
