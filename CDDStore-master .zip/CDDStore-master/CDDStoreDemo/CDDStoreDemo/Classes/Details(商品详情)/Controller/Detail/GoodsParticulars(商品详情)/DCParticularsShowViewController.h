//
//  DCParticularsShowViewController.h
//  CDDStoreDemo
//
//  Created by apple on 2017/9/7.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface DCParticularsShowViewController : UIViewController

/* url */
@property (strong , nonatomic)NSString *particularUrl;

@end
