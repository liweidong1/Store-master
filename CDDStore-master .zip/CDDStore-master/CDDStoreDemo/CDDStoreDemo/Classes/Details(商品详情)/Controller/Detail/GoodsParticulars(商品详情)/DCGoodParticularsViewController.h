//
//  DCGoodParticularsViewController.h
//  CDDMall
//
//  Created by apple on 2017/6/21.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <CDDPagerController/DCPagerController.h>

@interface DCGoodParticularsViewController : DCPagerController

@end
