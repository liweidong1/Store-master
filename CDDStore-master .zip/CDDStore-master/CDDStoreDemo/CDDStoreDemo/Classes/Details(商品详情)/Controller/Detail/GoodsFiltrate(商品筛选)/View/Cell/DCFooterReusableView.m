//
//  DCFooterReusableView.m
//  CDDStoreDemo
//
//  Created by apple on 2017/8/22.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCFooterReusableView.h"

// Controllers

// Models

// Views

// Vendors

// Categories

// Others

@interface DCFooterReusableView ()



@end

@implementation DCFooterReusableView

#pragma mark - Intial
- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
    
    }
    return self;
}

#pragma mark - Setter Getter Methods


@end
