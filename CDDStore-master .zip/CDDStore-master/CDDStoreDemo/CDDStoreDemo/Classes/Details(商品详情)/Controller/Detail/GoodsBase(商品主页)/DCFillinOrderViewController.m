//
//  DCFillinOrderViewController.m
//  CDDStoreDemo
//
//  Created by apple on 2017/7/18.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCFillinOrderViewController.h"

// Controllers

// Models

// Views

// Vendors

// Categories

// Others

@interface DCFillinOrderViewController ()



@end

@implementation DCFillinOrderViewController

#pragma mark - LazyLoad


#pragma mark - LifeCyle

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"填写订单";
}


@end
