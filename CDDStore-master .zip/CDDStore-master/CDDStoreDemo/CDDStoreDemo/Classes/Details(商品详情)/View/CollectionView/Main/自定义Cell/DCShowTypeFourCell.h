//
//  DCShowTypeFourCell.h
//  CDDMall
//
//  Created by apple on 2017/6/26.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCDetailShowTypeCell.h"

@interface DCShowTypeFourCell : DCDetailShowTypeCell

@end
