//
//  DCFeatureTitleItem.h
//  CDDStoreDemo
//
//  Created by apple on 2017/7/13.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DCFeatureTitleItem : NSObject

/** 标题名 */
@property (nonatomic, copy) NSString *attrname;


@end
