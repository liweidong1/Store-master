//
//  DCFeatureItem.m
//  CDDStoreDemo
//
//  Created by apple on 2017/7/13.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCFeatureItem.h"

@implementation DCFeatureItem

+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"list" : @"DCFeatureList"
             };
}


@end
