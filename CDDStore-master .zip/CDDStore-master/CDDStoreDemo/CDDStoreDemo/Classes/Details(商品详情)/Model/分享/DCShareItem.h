//
//  DCShareItem.h
//  CDDStoreDemo
//
//  Created by apple on 2017/7/11.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DCShareItem : NSObject

/** 品台  */
@property (nonatomic, copy ,readonly) NSString *terrace;

/** 图片  */
@property (nonatomic, copy ,readonly) NSString *iconImage;

@end
