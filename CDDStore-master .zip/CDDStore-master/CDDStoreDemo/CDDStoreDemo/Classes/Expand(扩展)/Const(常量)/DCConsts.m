//
//  DCConsts.m
//  CDDMall
//
//  Created by apple on 2017/5/26.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//


#import "DCConsts.h"

@implementation DCConsts

/** 常量数 */
CGFloat const DCMargin = 10;

/** 导航栏高度 */
CGFloat const DCNaviH = 44;

/** 底部tab高度 */
CGFloat const DCBottomTabH = 49;
/** 顶部Nav高度+指示器 */
CGFloat const DCTopNavH = 64;

@end
