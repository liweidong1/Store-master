//
//  DCClassMianItem.m
//  CDDMall
//
//  Created by apple on 2017/6/8.
//  Copyright © 2017年 RocketsChen. All rights reserved.
//

#import "DCClassMianItem.h"

@implementation DCClassMianItem

+(NSDictionary *)mj_objectClassInArray
{
    return @{
             @"goods" : @"DCCalssSubItem"
             };
}


@end
